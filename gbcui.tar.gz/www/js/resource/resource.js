'use strict';
angular.module('gbcui_shopApp.resource', [
    'gbcui_shopApp.resource.services'
]);
angular.module('gbcui_shopApp.resource.services', ['ngResource','LocalStorageModule']);

